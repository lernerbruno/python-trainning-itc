import sys

if __name__ == '__main__':
    print(int(sys.argv[1]) / int(sys.argv[2]))